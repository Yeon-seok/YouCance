package com.trip.config;

public class JwtConfiguration {

}
