import { css } from "styled-components";

const Wrapper = css`
    max-width: 80vw;
    margin: 0 auto;
`

export default Wrapper;